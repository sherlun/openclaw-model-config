import { spawnSync } from 'child_process'
import path from 'path'
import { fileURLToPath } from 'url'

const root = path.dirname(fileURLToPath(import.meta.url))

function run(cmd, args) {
  const result = spawnSync(cmd, args, {
    cwd: root,
    stdio: 'inherit',
    shell: true,
    env: { ...process.env },
  })
  if (result.status !== 0) process.exit(result.status ?? 1)
}

run('npm', ['run', 'build'])

const target = process.argv[2] || 'dir'
run('npx', ['--yes', 'electron-builder@latest', '--win', target])

if (target === 'dir') {
  run('npm', ['run', 'zip'])
}